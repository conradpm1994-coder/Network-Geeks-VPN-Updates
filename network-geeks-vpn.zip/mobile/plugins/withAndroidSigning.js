// Expo config plugin: signs release builds with a keystore taken from environment variables
// (KEYSTORE_PATH, KEYSTORE_PASSWORD, KEY_ALIAS, KEY_PASSWORD). Without them it falls back to the debug key.
const { withAppBuildGradle, createRunOncePlugin } = require('@expo/config-plugins');

const SIGNING = `        release {
            if (System.getenv('KEYSTORE_PATH')) {
                storeFile file(System.getenv('KEYSTORE_PATH'))
                storePassword System.getenv('KEYSTORE_PASSWORD')
                keyAlias System.getenv('KEY_ALIAS')
                keyPassword System.getenv('KEY_PASSWORD')
            }
        }
`;
function patch(s) {
  if (s.includes("System.getenv('KEYSTORE_PATH')")) return s;
  const re = /(buildTypes\s*\{[\s\S]*?release\s*\{[^}]*?)signingConfig signingConfigs\.debug/;
  if (!re.test(s)) throw new Error('with-android-signing: could not find the release signingConfig in app/build.gradle');
  s = s.replace(re, "$1signingConfig System.getenv('KEYSTORE_PATH') ? signingConfigs.release : signingConfigs.debug");
  if (!/signingConfigs\s*\{/.test(s)) throw new Error('with-android-signing: no signingConfigs block found');
  return s.replace(/signingConfigs\s*\{\n/, (m) => m + SIGNING);
}
const plugin = (config) => withAppBuildGradle(config, (c) => { c.modResults.contents = patch(c.modResults.contents); return c; });
module.exports = createRunOncePlugin(plugin, 'with-android-signing', '1.0.0');
module.exports.patch = patch;
