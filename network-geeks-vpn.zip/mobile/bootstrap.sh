#!/usr/bin/env bash
# Run ONCE on your machine, then commit package.json and package-lock.json.
# It lets Expo pick library versions that work together (the package.json uses "latest" as a starting point).
set -euo pipefail
cd "$(dirname "$0")"
npm install
npx expo install --fix
npx expo prebuild --platform android --no-install --clean
echo "Done. Commit package.json and package-lock.json. CI uses 'npm ci' from the lockfile."
