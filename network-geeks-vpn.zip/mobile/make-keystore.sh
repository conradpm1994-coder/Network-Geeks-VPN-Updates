#!/usr/bin/env bash
# Creates the Android upload keystore for Network Geeks VPN on YOUR machine and prints its SHA-1.
# Needs a JDK (keytool). You will be prompted for passwords and your organization details.
set -euo pipefail
KS="${1:-networkgeeks-upload.jks}"
ALIAS="networkgeeks"
[ -e "$KS" ] && { echo "$KS already exists. Refusing to overwrite."; exit 1; }
keytool -genkeypair -v -storetype PKCS12 -keystore "$KS" -alias "$ALIAS" \
  -keyalg RSA -keysize 2048 -validity 10000
echo; echo "=== Fingerprints (use SHA-1 for Google sign-in) ==="
keytool -list -v -keystore "$KS" -alias "$ALIAS" | grep -E "SHA1|SHA256"
echo; echo "Back up $KS and both passwords somewhere safe (password manager plus offline copy). Never commit it."
