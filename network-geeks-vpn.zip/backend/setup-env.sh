#!/usr/bin/env bash
# Fills empty JWT_SECRET, ADMIN_JWT_SECRET and OTP_PEPPER in .env with random values.
set -euo pipefail
cd "$(dirname "$0")"
for k in JWT_SECRET ADMIN_JWT_SECRET OTP_PEPPER; do
  if grep -qE "^$k=$" .env; then
    sed -i.bak "s|^$k=$|$k=$(openssl rand -hex 32)|" .env && rm -f .env.bak
    echo "set $k"
  else echo "$k already set, left alone"; fi
done
